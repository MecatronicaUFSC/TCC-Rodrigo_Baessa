import pandas

# read csv file
# new attribute for student class

# task name is always in top row of column
# info on whether or not the student concluded is in the same column as name
# if student concluded the task, timestamp will be on column+1 of task name on student's row

# task_conclusion = {
#   "task_name1": (True, datetime of conclusion)
#   "task_name2": (False, None) 
# }